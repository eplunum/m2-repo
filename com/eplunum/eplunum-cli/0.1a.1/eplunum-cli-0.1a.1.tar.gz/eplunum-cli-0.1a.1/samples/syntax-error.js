// Broken JavaScript code
this is not javascript