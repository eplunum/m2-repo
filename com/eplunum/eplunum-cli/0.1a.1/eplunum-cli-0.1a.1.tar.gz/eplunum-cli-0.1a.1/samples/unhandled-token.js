// bit shift operators not supported
var a = 2 << 4;