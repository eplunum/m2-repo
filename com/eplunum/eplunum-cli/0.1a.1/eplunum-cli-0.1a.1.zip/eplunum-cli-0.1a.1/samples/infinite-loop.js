// increments a counter each second forever
var x = 0;
while (true) {
  sleep(1000);
  print("Counter = " + x);
  x++;
}
